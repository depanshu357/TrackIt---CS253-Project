
import "./App.css";
import Login from "./components/Login";
import Register from "./components/Register";
import Type from "./components/Type";
import {Routes, Route} from "react-router-dom"
function App() {
  return (  
  <>
  <Routes>
    <Route path ='/' element={<Login/>}/>
    <Route path='/Type' element={<Type/>}/>
    <Route path ='/Register' element ={<Register/>}/>
  </Routes>
  </>
  );
}

export default App;
