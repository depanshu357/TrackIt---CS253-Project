import React from 'react';

const History = () => {
  return (
    <div
      style={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        height: '90vh'
      }}
    >
      <h1>History</h1>
    </div>
  );
};

export default History;