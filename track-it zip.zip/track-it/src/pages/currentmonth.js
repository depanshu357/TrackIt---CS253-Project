import React from 'react';

const CurrentMonth = () => {
  return (
    <div
      style={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        height: '90vh'
      }}
    >
      <h1>Current Month</h1>
    </div>
  );
};

export default CurrentMonth;